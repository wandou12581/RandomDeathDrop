package com.halfdrop;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * 配置文件：config/halfdrop.json。
 *
 * <pre>
 * {
 *   "global": {
 *     "dropPercent": 50,          // 掉落比例（%）
 *     "roundUp": true,            // 除不尽时向上取整
 *     "keepHotbar": true,         // 保留整个快捷栏
 *     "keepSelectedSlot": true,   // keepHotbar=false 时保留手持格
 *     "keepArmorSlot": true,      // 保留盔甲栏
 *     "keepWeaponOffhand": true,  // 保留副手
 *     "keepXP": false,            // true = 不掉经验
 *     "whiteList": ["minecraft:diamond"]
 *   },
 *   "players": [
 *     {
 *       "id": "Steve",            // 玩家名字或 UUID
 *       "dropPercent": 20,        // 缺省字段继承 global
 *       "keepArmorSlot": false,
 *       "whiteList": ["minecraft:enchanted_golden_apple"],
 *       "blackList": ["minecraft:netherite_ingot"]
 *     }
 *   ]
 * }
 * </pre>
 *
 * <p>个人字段为 null（JSON 里没写）时继承 global；白名单是「global 与个人取并集」，
 * 个人黑名单优先级最高（命中即取消白名单保护、正常参与随机）。
 */
public final class Config {
    public Global global = new Global();
    public List<PlayerEntry> players = new ArrayList<>();

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    public static final class Global {
        public int dropPercent = 50;
        public boolean roundUp = true;
        public boolean keepHotbar = true;
        public boolean keepSelectedSlot = true;
        public boolean keepArmorSlot = true;
        public boolean keepWeaponOffhand = true;
        public boolean keepXP = false;
        public List<String> whiteList = new ArrayList<>();
    }

    public static final class PlayerEntry {
        /** 玩家名字或 UUID。 */
        public String id = "";
        /** null = 继承 global。 */
        public Integer dropPercent;
        public Boolean roundUp;
        public Boolean keepHotbar;
        public Boolean keepSelectedSlot;
        public Boolean keepArmorSlot;
        public Boolean keepWeaponOffhand;
        public Boolean keepXP;
        /** null = 只用 global 白名单；非 null = global ∪ 本列表。 */
        public List<String> whiteList;
        /** 个人黑名单：命中即覆盖白名单、正常参与随机。 */
        public List<String> blackList;
    }

    public static Config load(Path path) {
        try {
            if (!Files.isRegularFile(path)) {
                Config cfg = new Config();
                save(path, cfg);
                return cfg;
            }

            String json = Files.readString(path, StandardCharsets.UTF_8);
            JsonElement root = JsonParser.parseString(json);

            // 旧版扁平结构（顶层直接是 dropPercent 等）→ 备份 + 生成新结构
            if (root.isJsonObject() && !root.getAsJsonObject().has("global")) {
                Path backup = path.resolveSibling(path.getFileName() + ".bak");
                Files.move(path, backup, StandardCopyOption.REPLACE_EXISTING);
                Config cfg = new Config();
                save(path, cfg);
                HalfdropCore.LOGGER.warn(
                        "[HalfDrop] old flat config detected, backed up to {} and generated the new structure",
                        backup.getFileName());
                return cfg;
            }

            Config cfg = GSON.fromJson(root, Config.class);
            if (cfg == null) {
                cfg = new Config();
            }
            if (cfg.global == null) {
                cfg.global = new Global();
            }
            if (cfg.players == null) {
                cfg.players = new ArrayList<>();
            }
            normalize(cfg);
            return cfg;
        } catch (Exception e) {
            HalfdropCore.LOGGER.warn("[HalfDrop] could not read config {}, using defaults", path, e);
            return new Config();
        }
    }

    public static void save(Path path, Config cfg) {
        try {
            Files.createDirectories(path.getParent());
            Files.writeString(path, GSON.toJson(cfg), StandardCharsets.UTF_8);
        } catch (Exception e) {
            HalfdropCore.LOGGER.warn("[HalfDrop] could not write config {}", path, e);
        }
    }

    /** 规范化物品 id（补 minecraft: 前缀、转小写）并清理非法条目。 */
    private static void normalize(Config cfg) {
        cfg.global.dropPercent = clamp(cfg.global.dropPercent);
        cfg.global.whiteList = normalizeIds(cfg.global.whiteList);

        for (PlayerEntry e : cfg.players) {
            if (e == null) {
                continue;
            }
            if (e.id == null) {
                e.id = "";
            }
            if (e.dropPercent != null) {
                e.dropPercent = clamp(e.dropPercent);
            }
            e.whiteList = e.whiteList == null ? null : normalizeIds(e.whiteList);
            e.blackList = e.blackList == null ? null : normalizeIds(e.blackList);
        }
    }

    private static int clamp(int percent) {
        return Math.max(0, Math.min(100, percent));
    }

    private static List<String> normalizeIds(List<String> ids) {
        List<String> out = new ArrayList<>();
        if (ids == null) {
            return out;
        }
        for (String raw : ids) {
            if (raw == null) {
                continue;
            }
            String id = raw.trim().toLowerCase(Locale.ROOT);
            if (id.isEmpty()) {
                continue;
            }
            if (!id.contains(":")) {
                id = "minecraft:" + id;
            }
            if (!out.contains(id)) {
                out.add(id);
            }
        }
        return out;
    }
}
