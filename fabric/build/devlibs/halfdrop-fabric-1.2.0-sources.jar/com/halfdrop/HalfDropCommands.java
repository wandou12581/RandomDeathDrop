package com.halfdrop;

import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;

/**
 * Fabric 侧命令注册：/halfdrop reload（需要 OP 权限）。
 */
public final class HalfDropCommands {
    private HalfDropCommands() {
    }

    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                dispatcher.register(Commands.literal("halfdrop")
                        .then(Commands.literal("reload")
                                .requires(source -> source.hasPermission(2))
                                .executes(context -> {
                                    HalfdropCore.reload();
                                    context.getSource().sendSuccess(
                                            () -> Component.literal("[HalfDrop] 配置已重载"), true);
                                    return 1;
                                }))));
    }
}
