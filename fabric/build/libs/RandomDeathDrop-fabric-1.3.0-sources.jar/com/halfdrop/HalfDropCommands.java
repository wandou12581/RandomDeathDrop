package com.halfdrop;

import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.tree.LiteralCommandNode;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;

/**
 * Fabric 侧命令：{@code /randomdeathdrop reload} 与 {@code /rdd reload}（需要 OP 权限）。
 *
 * <p>两个命令指向同一执行逻辑；旧的 {@code /halfdrop} 已移除。
 */
public final class HalfDropCommands {
    private HalfDropCommands() {
    }

    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            dispatcher.register(class_2170.method_9247("randomdeathdrop").then(reloadNode()));
            dispatcher.register(class_2170.method_9247("rdd").then(reloadNode()));
        });
    }

    private static LiteralCommandNode<class_2168> reloadNode() {
        return class_2170.method_9247("reload")
                .requires(source -> source.method_9259(2))
                .executes(HalfDropCommands::executeReload)
                .build();
    }

    private static int executeReload(CommandContext<class_2168> context) {
        HalfdropCore.reload();
        context.getSource().method_9226(() -> class_2561.method_43470("[RandomDeathDrop] 配置已重载"), true);
        return 1;
    }
}
