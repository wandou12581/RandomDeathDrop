package com.halfdrop.mixin;

import com.halfdrop.HalfdropCore;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_3222;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * 经验保留：{@code LivingEntity.dropExperience(Entity)} 是死亡掉落经验的入口。
 *
 * <p>当玩家生效配置里 {@code keepXP=true} 时取消这次经验掉落（等级与经验保留，
 * 重生后仍在）；其他生物或 {@code keepXP=false} 时保持原版行为。
 */
@Mixin(class_1309.class)
public abstract class KeepXpMixin {

    @Inject(method = "dropExperience", at = @At("HEAD"), cancellable = true)
    private void halfdrop$keepXp(class_1297 killer, CallbackInfo ci) {
        if ((Object) this instanceof class_3222 player && HalfdropCore.settingsFor(player).keepXP) {
            ci.cancel();
        }
    }
}
