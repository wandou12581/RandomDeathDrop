package com.halfdrop;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * 配置文件：config/halfdrop.json（首次启动自动生成）。
 *
 * <p>盔甲 4 格与副手 1 格固定保留（本模组的核心行为），不提供开关，避免误配。
 */
public final class Config {
    /** 掉落比例（百分比），默认 50。 */
    public int dropPercent = 50;

    /** true = 掉落格数向上取整（ceil），false = 向下取整。 */
    public boolean roundUp = true;

    /** 保留整个快捷栏 9 格（默认 true：只随机主背包 27 格）。 */
    public boolean keepHotbar = true;

    /** keepHotbar=false 时，是否仍保留当前手持的那一格。 */
    public boolean keepSelectedSlot = true;

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    public static Config load(Path path) {
        Config cfg = new Config();
        try {
            if (Files.isRegularFile(path)) {
                String json = Files.readString(path, StandardCharsets.UTF_8);
                Config parsed = GSON.fromJson(json, Config.class);
                if (parsed != null) {
                    cfg = parsed;
                }
            } else {
                Files.createDirectories(path.getParent());
                Files.writeString(path, GSON.toJson(cfg), StandardCharsets.UTF_8);
            }
        } catch (Exception e) {
            HalfdropCore.LOGGER.warn("[HalfDrop] could not read config {}, using defaults", path, e);
        }
        cfg.dropPercent = Math.max(0, Math.min(100, cfg.dropPercent));
        return cfg;
    }
}
