package com.halfdrop;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_3222;

/**
 * 死亡掉落计算：把原版「掉落全部」替换成「按格子随机掉落一部分」。
 *
 * <p>只处理主背包：槽位 0-8 是快捷栏、9-35 是主背包；盔甲（36-39）与副手（40）由
 * {@code Player.dropEquipment()} 里被重定向掉的 {@code Inventory.dropAll()} 一并跳过，因此永久保留。
 *
 * <p>性能：只在死亡瞬间执行一次，最多遍历 36 格 + 对前 k 个做部分 Fisher-Yates，
 * 之后每格调一次原版 {@code player.drop(...)}；没有 tick 循环、没有全局扫描，
 * 50 名玩家同时死亡时总开销仍是每人一次 O(36)，可忽略。
 */
public final class DeathDrop {
    /** 主背包槽位数（含快捷栏 9 格）。 */
    private static final int MAIN_SIZE = 36;
    /** 快捷栏格数。 */
    private static final int HOTBAR_SIZE = 9;

    private DeathDrop() {
    }

    public static void dropOnDeath(class_3222 player, class_1661 inventory) {
        Config cfg = HalfdropCore.config();

        int selected = inventory.field_7545;
        List<Integer> filled = new ArrayList<>(MAIN_SIZE);

        for (int slot = 0; slot < MAIN_SIZE; slot++) {
            // 快捷栏 9 格默认整段保留
            if (cfg.keepHotbar && slot < HOTBAR_SIZE) {
                continue;
            }
            // 不保留快捷栏时，当前手持的那一格仍然保留
            if (!cfg.keepHotbar && cfg.keepSelectedSlot && slot == selected) {
                continue;
            }
            if (!inventory.method_5438(slot).method_7960()) {
                filled.add(slot);
            }
        }

        int n = filled.size();
        if (n == 0) {
            return;
        }

        // 掉落格数 = ceil(n * dropPercent%)；除不尽时向上取整（例：9 格掉 5 格）
        int k = cfg.roundUp
                ? (int) Math.ceil(n * (cfg.dropPercent / 100.0))
                : (int) Math.floor(n * (cfg.dropPercent / 100.0));
        if (k <= 0) {
            return;
        }
        if (k > n) {
            k = n;
        }

        // 部分洗牌：只洗前 k 个，O(k)，避免整表随机排序
        ThreadLocalRandom random = ThreadLocalRandom.current();
        for (int i = 0; i < k; i++) {
            int j = i + random.nextInt(n - i);
            int tmp = filled.get(i);
            filled.set(i, filled.get(j));
            filled.set(j, tmp);
        }

        for (int i = 0; i < k; i++) {
            int slot = filled.get(i);
            class_1799 stack = inventory.method_5438(slot);
            if (stack.method_7960()) {
                continue;
            }
            // 与原版 PlayerInventory.dropAll() 完全相同的调用：
            // 随机方向散开、40 tick 拾取延迟、归属于该玩家（thrower UUID），动画与原版一致。
            player.method_7329(stack, true, false);
            inventory.method_5447(slot, class_1799.field_8037);
        }
    }
}
