package com.halfdrop;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.file.Path;

/**
 * 平台无关的模组核心：持有配置、提供初始化入口。
 *
 * <p>Fabric 侧在 {@code ModInitializer} 里传入 {@code FabricLoader.getConfigDir()}，
 * NeoForge 侧在 {@code @Mod} 构造器里传入 {@code FMLPaths.CONFIGDIR.get()}。
 */
public final class HalfdropCore {
    public static final String MOD_ID = "halfdrop";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    private static Config config = new Config();

    private HalfdropCore() {
    }

    public static void init(Path configDir) {
        config = Config.load(configDir.resolve(MOD_ID + ".json"));
        LOGGER.info("[HalfDrop] loaded: dropPercent={}% roundUp={} keepHotbar={} keepSelectedSlot={}",
                config.dropPercent, config.roundUp, config.keepHotbar, config.keepSelectedSlot);
    }

    public static Config config() {
        return config;
    }
}
