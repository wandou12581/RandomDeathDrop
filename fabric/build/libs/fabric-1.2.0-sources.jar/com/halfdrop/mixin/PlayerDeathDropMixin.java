package com.halfdrop.mixin;

import com.halfdrop.DeathDrop;
import net.minecraft.class_1661;
import net.minecraft.class_3222;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * 拦截 {@code Inventory.dropAll()}（原版死亡掉落全部物品的唯一入口）：
 * 服务端玩家死亡时改成按规则随机掉落；客户端（单人游戏的客户端侧）与原版行为保持不变。
 */
@Mixin(class_1661.class)
public abstract class PlayerDeathDropMixin {

    @Inject(method = "dropAll()V", at = @At("HEAD"), cancellable = true)
    private void halfdrop$dropRandomPart(CallbackInfo ci) {
        class_1661 self = (class_1661) (Object) this;
        if (self.field_7546 instanceof class_3222 serverPlayer) {
            DeathDrop.dropOnDeath(serverPlayer, self);
            ci.cancel();
        }
    }
}
