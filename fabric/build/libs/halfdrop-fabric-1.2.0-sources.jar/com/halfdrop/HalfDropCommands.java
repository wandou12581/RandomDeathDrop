package com.halfdrop;

import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_2170;
import net.minecraft.class_2561;

/**
 * Fabric 侧命令注册：/halfdrop reload（需要 OP 权限）。
 */
public final class HalfDropCommands {
    private HalfDropCommands() {
    }

    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                dispatcher.register(class_2170.method_9247("halfdrop")
                        .then(class_2170.method_9247("reload")
                                .requires(source -> source.method_9259(2))
                                .executes(context -> {
                                    HalfdropCore.reload();
                                    context.getSource().method_9226(
                                            () -> class_2561.method_43470("[HalfDrop] 配置已重载"), true);
                                    return 1;
                                }))));
    }
}
